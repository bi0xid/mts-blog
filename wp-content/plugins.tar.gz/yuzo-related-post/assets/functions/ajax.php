<?php 

$action = $_REQUEST["yuzo_actions"];

if( $action == "transient" ){ // delete transient



}

?>
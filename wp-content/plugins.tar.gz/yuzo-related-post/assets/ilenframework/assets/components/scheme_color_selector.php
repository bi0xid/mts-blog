<?php

    global $scheme_color;

    $scheme_color = array(
                          'red'=>'#E64946',
                          'blue'=>'#0088CC',
                          'black'=>'#6D6D6D',
                          'turke'=>'#00CEF7',
                          'green2'=>'#4AEF9D',
                          'black2'=>'#383E4B',
                         );


?>